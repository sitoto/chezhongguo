(function(){}).call(this);
